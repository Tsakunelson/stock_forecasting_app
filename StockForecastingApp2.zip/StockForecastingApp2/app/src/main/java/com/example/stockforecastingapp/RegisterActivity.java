package com.example.stockforecastingapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText emailEditText, pwdEditText, fullNameEditText ;
    Button registerButton, cancelButton;
    String NameHolder, EmailHolder, PasswordHolder;
    Boolean EditTextEmptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    String SQLiteDataBaseQueryHolder ;
    SQLiteHelper sqLiteHelper;
    Cursor cursor;
    String Found_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        registerButton = (Button)findViewById(R.id.registerUserButton);
        cancelButton = (Button) findViewById(R.id.cancelButton);
        emailEditText = (EditText)findViewById(R.id.emailEditText);
        pwdEditText = (EditText)findViewById(R.id.pwdEditText);
        fullNameEditText = (EditText)findViewById(R.id.nameEditText);
        sqLiteHelper = new SQLiteHelper(this);

        // Register onClick listener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create SQLite database if not exists
                dbBuild();
                // Create SQLite table if not exists
                buildDbTable();
                // Check if EditText is empty or not
                CheckEditTextStatus();
                // check if Email is already registered
                CheckingEmailAlreadyExistsOrNot();
                // Clear the EditText after the registration is complete
                ClearEditTextAfterDataInsert();
            }
        });
    }

    public void onClickCancelRegisterButton(View view) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    public void dbBuild(){
        sqLiteDatabaseObj = openOrCreateDatabase(SQLiteHelper.DATABASE_NAME, Context.MODE_PRIVATE, null);
    }

    public void buildDbTable() {
        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " + SQLiteHelper.TABLE_NAME + "(" + SQLiteHelper.Table_Column_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " + SQLiteHelper.Table_Column_1_Name + " VARCHAR, " + SQLiteHelper.Table_Column_2_Email + " VARCHAR, " + SQLiteHelper.Table_Column_3_Password + " VARCHAR);");
    }

    // Insert data into DB.
    public void InsertDataIntoDB(){
        if(EditTextEmptyHolder == true)
        {
            SQLiteDataBaseQueryHolder = "INSERT INTO "+SQLiteHelper.TABLE_NAME+" (name,email,password) VALUES('"+NameHolder+"', '"+EmailHolder+"', '"+PasswordHolder+"');";
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);
            sqLiteDatabaseObj.close();
            finish();
            startActivity(new Intent(this, MainActivity.class));
            Toast.makeText(RegisterActivity.this,"User Registered Successfully", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(RegisterActivity.this,"Please Fill All The Required Fields.", Toast.LENGTH_LONG).show();
        }
    }

    // Clear the EditText after the registration is complete.
    public void ClearEditTextAfterDataInsert(){
        fullNameEditText.getText().clear();
        emailEditText.getText().clear();
        pwdEditText.getText().clear();
    }

    // Check if EditText is empty or not
    public void CheckEditTextStatus(){
        NameHolder = fullNameEditText.getText().toString() ;
        EmailHolder = emailEditText.getText().toString();
        PasswordHolder = pwdEditText.getText().toString();
        if(TextUtils.isEmpty(NameHolder) || TextUtils.isEmpty(EmailHolder) || TextUtils.isEmpty(PasswordHolder)){
            EditTextEmptyHolder = false ;
        }
        else {
            EditTextEmptyHolder = true ;
        }
    }

    // Check Email is already registered
    public void CheckingEmailAlreadyExistsOrNot(){
        sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();
        cursor = sqLiteDatabaseObj.query(SQLiteHelper.TABLE_NAME, null, " " + SQLiteHelper.Table_Column_2_Email + "=?", new String[]{EmailHolder}, null, null, null);
        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                Found_Result = "Email Found";
                cursor.close();
            }
        }
        CheckResult();
    }

    // Checking result
    public void CheckResult(){
        if(Found_Result.equalsIgnoreCase("Email Found"))
        {
            Toast.makeText(RegisterActivity.this,"Email Entered Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            InsertDataIntoDB();
        }
        Found_Result = "Not_Found" ;
    }
}
