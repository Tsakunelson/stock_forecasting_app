package com.example.stockforecastingapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserDashboardActivity extends AppCompatActivity {
    String EmailHolder;
    TextView Email;
    Button logoutButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Email = (TextView)findViewById(R.id.textView1);
        logoutButton = (Button)findViewById(R.id.logoutButton);
        Intent intent = getIntent();
        EmailHolder = intent.getStringExtra(MainActivity.UserEmail);
        Email.setText(Email.getText().toString()+ EmailHolder);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                startActivity(new Intent(UserDashboardActivity.this, MainActivity.class));
                Toast.makeText(UserDashboardActivity.this,"Successfully Logged Out of Stock Forecasting App", Toast.LENGTH_LONG).show();
            }
        });

    }
}
