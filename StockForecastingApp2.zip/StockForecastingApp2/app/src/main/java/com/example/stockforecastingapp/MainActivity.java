package com.example.stockforecastingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button loginButton, registerButton ;
    EditText emailEditText, pwdEditText ;
    String EmailHolder, PasswordHolder;
    Boolean EditTextEmptyHolder;
    SQLiteDatabase sqLiteDatabaseObj;
    SQLiteHelper sqLiteHelper;
    Cursor cursor;
    String TempPassword = "NOT_FOUND" ;
    public static final String UserEmail = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loginButton = (Button)findViewById(R.id.loginButton);
        registerButton = (Button)findViewById(R.id.registerUserButton);
        emailEditText = (EditText)findViewById(R.id.emailEditText);
        pwdEditText = (EditText)findViewById(R.id.pwdEditText);
        sqLiteHelper = new SQLiteHelper(this);

        //Login onClick listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the EditText is empty
                CheckEditTextStatus();
                // Invoke login method.
                loginFunction();
            }
        });

        // Register onClick listener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Register will navigate the user to the RegisterActivity screen
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    // Login Function implementation
    public void loginFunction(){
        if(EditTextEmptyHolder) {
            // Open SQLite DB write permission.
            sqLiteDatabaseObj = sqLiteHelper.getWritableDatabase();
            // Adding search email query to cursor.
            cursor = sqLiteDatabaseObj.query(SQLiteHelper.TABLE_NAME, null, " " + SQLiteHelper.Table_Column_2_Email + "=?", new String[]{EmailHolder}, null, null, null);
            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();
                    // Store pwd associated with the email.
                    TempPassword = cursor.getString(cursor.getColumnIndex(SQLiteHelper.Table_Column_3_Password));
                    // Close cursor.
                    cursor.close();
                }
            }
            CheckResult();
        }
        else {
            Toast.makeText(MainActivity.this,"Please Enter Email Address or Password.",Toast.LENGTH_LONG).show();
        }
    }

    // Check if EditText is empty or not.
    public void CheckEditTextStatus(){
        EmailHolder = emailEditText.getText().toString();
        PasswordHolder = pwdEditText.getText().toString();

        if( TextUtils.isEmpty(EmailHolder) || TextUtils.isEmpty(PasswordHolder)){
            EditTextEmptyHolder = false ;
        }
        else {
            EditTextEmptyHolder = true ;
        }
    }

    // Check the password entered from SQLite DB using the email associated password.
    public void CheckResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder))
        {
            Toast.makeText(MainActivity.this,"Logged in Successfully",Toast.LENGTH_LONG).show();
            // Navigate the logged in user to UserDashboard activity
            Intent intent = new Intent(MainActivity.this, UserDashboardActivity.class);
            // Sending Email to Dashboard Activity using intent.
            intent.putExtra(UserEmail, EmailHolder);
            startActivity(intent);
        }
        else {
            Toast.makeText(MainActivity.this,"User Email Address or Password entered is Wrong, Please Try Again.",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND";
    }
}
