package com.example.ntsaku.mobilelinearregression;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;
import org.json.JSONArray;

import java.util.List;
import java.util.ArrayList;


public class StockData {
    private static String dataURL ="https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=MSFT&interval=5min&outputsize=full&apikey=demo";
    private static String streamToString(InputStream inputStream) {
        String text = new Scanner(inputStream, "UTF-8").useDelimiter("\\Z").next();
        return text;
    }

    public static String jsonGetRequest(String urlQueryString) {
        String json = null;
        try {
            URL url = new URL(urlQueryString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("charset", "utf-8");
            connection.connect();
            InputStream inStream = connection.getInputStream();
            json = streamToString(inStream); // input stream to string
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return json;
    }
    public static void main(String args[]) throws org.json.JSONException{
        String json = jsonGetRequest(dataURL);
        System.out.println(json);
        JSONObject obj = new JSONObject(json);

        List<String> list = new ArrayList<String>();

        JSONArray array = obj.getJSONArray("2019-06-27 09:40:00");
        for(int i = 0 ; i < array.length() ; i++){
            list.add(array.getJSONObject(i).getString("open"));
        }
        System.out.println(list.toString());

        //return true;
    }

}

