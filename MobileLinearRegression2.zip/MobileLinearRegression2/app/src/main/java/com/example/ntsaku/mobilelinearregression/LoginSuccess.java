package com.example.ntsaku.mobilelinearregression;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class LoginSuccess extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_longin_success);
        String userName = getIntent().getStringExtra("Username");
        TextView textView = (TextView) findViewById(R.id.loginUserNametextView);
        textView.setText(userName);
    }
}
