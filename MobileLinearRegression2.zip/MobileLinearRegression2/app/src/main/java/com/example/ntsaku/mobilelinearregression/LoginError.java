package com.example.ntsaku.mobilelinearregression;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginError extends AppCompatActivity {
    EditText userNameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_error);
        userNameEditText = (EditText) findViewById(R.id.emailTextView);
        passwordEditText = (EditText) findViewById(R.id.pwdextView);

    }
    public void onGoBackButtonClicked(View view) {
        finish();
        startActivity(new Intent(this, MainActivity.class));
        userNameEditText = (EditText) findViewById(R.id.emailTextView);
        passwordEditText = (EditText) findViewById(R.id.pwdextView);
        //userNameEditText.setText("");
        //passwordEditText.setText("");
    }
}
