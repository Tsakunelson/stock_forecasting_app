package com.example.ntsaku.mobilelinearregression;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.os.AsyncTask;
import com.jjoe64.graphview.*;
import org.json.JSONException;
import org.tensorflow.contrib.android.TensorFlowInferenceInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.URL;
import java.net.MalformedURLException;
import org.json.JSONObject;
import org.json.JSONArray;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.text.ParseException;


import com.example.ntsaku.mobilelinearregression.StockData;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.IOException;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private static final String MODEL_NAME = "file:///android_asset/optimized_frozen_linear_regression.pb";
    private static final String INPUT_NODE = "x";
    private static final String OUTPUT_NODE = "y_output";
    private static final long[] INPUT_SHAPE = {1L, 1L};
    private static TensorFlowInferenceInterface tensorFlowInferenceInterface;

    private EditText editText;
    private TextView textView, textView4;
    HttpURLConnection connection = null;
    BufferedReader reader = null;
    JSONObject obj;
    String str;
    List<Double> openPrice;
    List<Integer> dates;
    LineGraphSeries<DataPoint> series;
    GraphView graph;

    private static String streamToString(InputStream inputStream) throws IOException {

        String line;
        String text = new Scanner(inputStream, "UTF-8").useDelimiter("\\Z").next();
        return text;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText2);
        textView = findViewById(R.id.textView3);
        //textView4 = findViewById(R.id.textView4);
        graph = (GraphView) findViewById(R.id.graph);
        //graph = initGraphView(graph);


        tensorFlowInferenceInterface = new TensorFlowInferenceInterface(getAssets(), MODEL_NAME);

//
        new getData().execute();


    }

    public void pressButton(View view) throws IOException, JSONException {
        float input = Float.parseFloat(editText.getText().toString());
        String results = performInference(input);
        textView.setText(results);
    }

    private String performInference(float input) throws IOException, JSONException {
        float[] floatArray = {input};

        tensorFlowInferenceInterface.feed(INPUT_NODE, floatArray, INPUT_SHAPE);
        tensorFlowInferenceInterface.run(new String[] {OUTPUT_NODE});
        //textView4.setText(StockData.jsonGetRequest(dataURL));

        float[] results = {0.0f};
        tensorFlowInferenceInterface.fetch(OUTPUT_NODE, results);

        return String.valueOf(results[0]);
    }

    private class getData extends AsyncTask<String, String, String>  {

        @Override
        protected String doInBackground(String... params)  {
            try {
                URL url = new URL("http://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=MSFT&interval=5min&outputsize=full&apikey=demo");
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                String redirect = connection.getHeaderField("Location");
                if (redirect != null){
                    connection = (HttpURLConnection) new URL(redirect).openConnection();
                }

                InputStream stream = connection.getInputStream();

                str = streamToString(stream);
                obj = new JSONObject(str);
                //parse JSON object
                openPrice = new ArrayList<Double>();
                dates = new ArrayList<Integer>();


                //JSONArray array = (JSONArray) obj.getJSONArray("Time Series (5min)");
                obj= obj.getJSONObject("Time Series (5min)");
                Iterator x = obj.keys();
                JSONArray stock = new JSONArray();

                SimpleDateFormat temp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


                while (x.hasNext()){
                    String key = (String) x.next();
                    stock.put(obj.get(key));
                    //dates.add(key);
                    Integer hour = temp.parse(key).getHours();
                    Integer min = temp.parse(key).getMinutes();
                    dates.add(Integer.parseInt(hour+""+min));
                    openPrice.add(Double.parseDouble(obj.getJSONObject(key).getString("1. open")));

                }
                System.out.println(dates.size());
                System.out.println(openPrice.size());
//                String filePath =  "C:\\Users\\ntsaku\\Downloads\\android-yolo-v2-master\\";
//                File f = new File(filePath+"prices.txt");
//                File f1 = new File(filePath+"dates.txt");
//
//                FileOutputStream fos = openFileOutput(filePath+"prices.txt", Context.MODE_PRIVATE);
//                FileOutputStream fos1 = openFileOutput(filePath+"dates.txt", Context.MODE_PRIVATE);
//                //PrintWriter pw1 = new PrintWriter(new FileOutputStream(f1));
//
//                for (Double price : openPrice)
//                    fos.write(price.byteValue());
//                for (Integer date : dates)
//                    fos1.write(date.byteValue());
//
//                fos.close();
//                fos1.close();
//                FileWriter writer = new FileWriter(filePath+"prices.txt");
//                for(Double price: openPrice) {
//                    writer.write(price + System.lineSeparator());
//                }
//                writer.close();





                //System.out.println("The Time series array .......... "+ stock.toString());
                //System.out.println("The Json length .......... "+ stock.length());


//                series = new LineGraphSeries<DataPoint>(new DataPoint[] {
//                        new DataPoint(0, 1),
//                        new DataPoint(1, 5),
//                        new DataPoint(2, 3),
//                        new DataPoint(3, 2),
//                        new DataPoint(4, 6)
//                });

//                Map<Integer,Double> map = new LinkedHashMap<Integer,Double>();  // ordered
//
//                for (int i=0; i<openPrice.size(); i++) {
//                    map.put(dates.get(i), openPrice.get(i));    // is there a clearer way?
//                }
//
//                System.out.println(map);


                DataPoint[] values = new DataPoint[openPrice.size()];
                for (int i=0; i<openPrice.size(); i++) {

                    DataPoint v = new DataPoint(i, openPrice.get(i));
                    values[i] = v;
                }
                series = new LineGraphSeries<DataPoint>(values);


              // series.appendData(new DataPoint(0, 1));




                System.out.println(obj.toString());
                System.out.println("Open prices : "+ openPrice.toString());
                System.out.println("Dates : "+ dates.toString());

                return obj.toString();

        }catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            catch ( JSONException je){
                je.printStackTrace();
            }catch ( ParseException pe){
                pe.printStackTrace();
            }finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }


        //@Override
        protected void onPostExecute(String result)  {
            super.onPostExecute(result);
            System.out.println("............In onpostExecute .....................");
            System.out.println(result);
            graph.addSeries(series);

        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            System.out.println("Data Loading........................................");

        }

//        @Override
//        protected void onProgressUpdate(Void... values) {}
    }

}
