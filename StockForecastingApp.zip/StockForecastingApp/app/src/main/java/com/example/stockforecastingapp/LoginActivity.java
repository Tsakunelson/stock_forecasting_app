package com.example.stockforecastingapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends Activity {

    Button loginButton, signUpButton;
    EditText userNameEditText, passwordEditText;
    private List<UserModel> userRecordsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        readUserData(); // List of all user records
        userNameEditText = (EditText) findViewById(R.id.emailTextView);
        passwordEditText = (EditText) findViewById(R.id.pwdextView);
        loginButton = (Button) findViewById(R.id.okButton);
        signUpButton = (Button) findViewById(R.id.signUpButton);
    }

    private void readUserData() {
        // Read the raw csv file
        InputStream is = getResources().openRawResource(R.raw.useraccounts);
        // Reads text from character-input stream, buffering characters for efficient reading
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );
        // Initialization
        String line = "";

        // Initialization
        try {
            // Step over headers
            reader.readLine();

            // If buffer is not empty
            while ((line = reader.readLine()) != null) {
                Log.d("MyActivity", "Line: " + line);
                // use comma as separator columns of CSV
                String[] tokens = line.split(",");
                // Read the data
                UserModel userObj = new UserModel();

                // Setters
                userObj.setEmail(tokens[0]);
                userObj.setPassword(tokens[1]);
                userObj.setFullname(tokens[2]);

                // Adding object to a class
                userRecordsList.add(userObj);

                // Log the object
                Log.d("My Activity", "Just created: " + userObj);
            }

        } catch (IOException e) {
            // Logs error with priority level
            Log.wtf("MyActivity", "Error reading data file on line" + line, e);

            // Prints throwable details
            e.printStackTrace();
        }
    }

    public void onLoginButtonClicked(View view) {
        for(UserModel user: userRecordsList) {
            if(userNameEditText.getText().toString().equals(user.getEmail()) && passwordEditText.getText().toString().equals(user.getPassword())) {
                String userNameStr = user.getFullname();
                Intent i = new Intent(LoginActivity.this, LoginSuccess.class);
                i.putExtra("Username", userNameStr);
                startActivity(i);
            } else {
                Intent i = new Intent(LoginActivity.this, LoginError.class);
                startActivity(i);
            }
        }
    }

    public void onSignUpButtonClicked(View view) {
        Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(i);
    }
}
