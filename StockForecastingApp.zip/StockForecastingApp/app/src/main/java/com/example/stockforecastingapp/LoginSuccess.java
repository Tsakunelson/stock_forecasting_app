package com.example.stockforecastingapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class LoginSuccess  extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_success);
        String userName = getIntent().getStringExtra("Username");
        TextView textView = (TextView) findViewById(R.id.loginUserNametextView);
        textView.setText(userName);
    }
}
