package com.example.stockforecastingapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends Activity {

    Button registerButton, cancelButton;
    EditText fullName, email, pwd;
    private List<UserModel> userRecordsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        fullName = (EditText) findViewById(R.id.fullNameTextView);
        email = (EditText) findViewById(R.id.emailTextView);
        pwd = (EditText) findViewById(R.id.pwdTextView);
        registerButton = (Button) findViewById(R.id.registerButton);
        cancelButton = (Button) findViewById(R.id.cancelButton);
    }

    public void onClickRegisterButton(View view) {
        InputStream is = getResources().openRawResource(R.raw.useraccounts);
        fullName = (EditText) findViewById(R.id.fullNameTextView);
        email = (EditText) findViewById(R.id.emailTextView);
        pwd = (EditText) findViewById(R.id.pwdTextView);
        try {
            FileWriter output = new FileWriter(String.valueOf(is),true); //the true will append the new data
            output.append(String.valueOf(email)+","+String.valueOf(pwd)+","+String.valueOf(fullName));
            output.flush();
            output.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }

        Intent i = new Intent(this, LoginActivity.class);
        startActivity(i);
    }

    public void onClickCancelRegisterButton(View view) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
